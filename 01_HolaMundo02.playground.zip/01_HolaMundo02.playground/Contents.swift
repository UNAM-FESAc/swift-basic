/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos
var carita = "Hi guys,"
var mano = "I love to study progra II course"
print(carita, mano)
