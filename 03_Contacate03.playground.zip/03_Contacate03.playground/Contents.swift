/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

var sal:String = "Hello ";
var nam:String = "Javier";
var num1 = 3;

// interpolar
var mensaje = "\(sal) \(nam) tu \"turno\" es \(num1)";

print(mensaje);
