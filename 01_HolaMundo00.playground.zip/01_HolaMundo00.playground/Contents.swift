/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos
var str2 : String = "Hi"
var StrJAOD : String = "Hello, playground"
print(str2, StrJAOD)
