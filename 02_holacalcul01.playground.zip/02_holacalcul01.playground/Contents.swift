/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos
let a = 2
let b = 3
let c = a+b

print(c)
