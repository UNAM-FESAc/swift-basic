/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos
var a = "i"
let b = "j"
let c = a+b

print(c)
