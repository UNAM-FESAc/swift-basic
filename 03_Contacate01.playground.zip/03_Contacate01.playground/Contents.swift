/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

// Anotación de Tipo
var sal:String = "Hello ";
var nam:String = "Javier";

var mensaje = sal + nam;
print(mensaje);
