/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

let MaxVideoLength = 5
let OptVideoLength = 3
let MinVideoLength = 1
let RealLenght = 6

if (RealLenght>=MaxVideoLength){
    print("Muy largo  😣")
}
else if (RealLenght<=MaxVideoLength&&RealLenght>=OptVideoLength){
    print("Medio  😮")
}else{
    print("Muy bien 😁")
}

