/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos
enum month{
    case Jan, Feb, Mar, Jun
}

let vlA = 1
var mySmmr = 3

switch vlA {
    
case vlA..<mySmmr:
    print("Estamos en Invierno: Mes \(month.Feb)")
default:
    print("Nada")
}

