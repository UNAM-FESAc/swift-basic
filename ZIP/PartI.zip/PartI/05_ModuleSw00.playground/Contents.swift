/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos
import UIKit

var today = Date()
print(today)
