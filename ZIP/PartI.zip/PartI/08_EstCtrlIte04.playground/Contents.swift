/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

for k in stride(from: 10, through: 1, by: -2){
    print("hola", k, k * 2, k * k)
}
