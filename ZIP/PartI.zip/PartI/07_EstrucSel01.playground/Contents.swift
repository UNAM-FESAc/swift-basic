/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos
var a = 20;

if (a % 2 == 0 && a>=10){
    print("Es par");print("Es mayor que 10")
}else{
    print("Es impar");print("Es mayor que 10")
}

