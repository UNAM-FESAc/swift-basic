/*
 
/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos
var carita : Character = "😃"
var mano = "I love to study progra I course"
print(carita, mano)

 */

var 😍=2
var 😎=3
var 😘=😍+😎
print(😘)
