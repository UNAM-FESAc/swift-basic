/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

// Anotación de Tipo
var sal:String = "Hello "
var nam:String = "Javier";
var num1:Double = 3.0
var num3:Double = 5.0
// Inferencia de tipo
var num2 = 2
// Concatenar
var mensaje = sal + nam + " \(num1) " + " \(num3) "
// interpolar
var mensaje2 = "\(sal) \(nam) tu  \"turno\" es \(num2)";

print(mensaje);
print(mensaje2);
