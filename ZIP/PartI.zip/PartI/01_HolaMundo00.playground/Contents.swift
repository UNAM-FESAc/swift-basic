/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

var saludo="Hi!"
var GrupoConsentidos="I love programming.";

print(saludo,GrupoConsentidos)
