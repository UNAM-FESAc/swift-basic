/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

let a = 10
let b = 3
let ms1:String="Bueno "
let ms2:String="Malo "

if (a<=b){
    print(ms1+"\(a)<\(b) ✅")
}else {
    print(ms2+"\(a) > \(b) ❌")
}
