/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

for _ in 1...5{
    print("hola")
}
