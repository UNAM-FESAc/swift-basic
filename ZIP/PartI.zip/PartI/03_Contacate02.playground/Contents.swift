/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

// Inferencia de tipo
var sal = "Hello ";
var nam = "Javier";

// Concatenar
var mensaje = sal + nam;

print(mensaje);
