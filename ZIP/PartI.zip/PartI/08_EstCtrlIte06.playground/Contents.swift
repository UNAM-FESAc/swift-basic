/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

var fruits = ["banana","orange","cherry", "Watermelon"]
var animals = ["monkey","cow","dog"]
var numbers = [1, 10, 100]


// #1
for f in fruits{
    print(f)
}
// #2
for f in animals{
    print("\(f)")
}

// #3
for f in numbers{
    print(f)
}


