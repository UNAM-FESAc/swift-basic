/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

enum months{
    case Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
}

print(months.Jan)


