
/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

let a:Int = 20
let b:Int = 30

if (a>=b){print("y")}else{print("n")}
