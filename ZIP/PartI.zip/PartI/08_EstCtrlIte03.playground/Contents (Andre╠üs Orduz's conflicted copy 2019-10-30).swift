/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

for j in stride(from:-100,to:120,by:20){
    print(j);
}
