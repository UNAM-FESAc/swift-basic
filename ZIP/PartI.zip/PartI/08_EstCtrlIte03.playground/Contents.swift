/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

for j in stride(from: -100, to: 100, by: 20){
    print(j);
}
