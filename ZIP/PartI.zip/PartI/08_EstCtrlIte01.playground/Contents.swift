/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

var i:Float32 = -4.1

while i<=5{
    print("Hola mundo \(i)");
    i+=2;
}
