/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

for var i in -3...2{
    print(i);
  i-=(-1);
}
