/*
 ********************* TEXTO SIN ACENTOS ********************
 https://repl.it
 */
// Recuerda documentar tus codigos

var letra:Character="🍒";

var cadena:String="\(letra) todos: Hola Mundo"

print(cadena)

