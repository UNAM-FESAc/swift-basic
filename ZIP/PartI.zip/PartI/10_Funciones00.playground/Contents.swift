/* ********************* TEXTO SIN ACENTOS *********************/

// Recuerda documentar tus codigos

func area(_ base:Double,_ altura:Double) -> Double{
    let area = base * altura;
    return area;
    
}
let areaRec = area(10, 3);

print("\(areaRec) unidades cuadradas");


