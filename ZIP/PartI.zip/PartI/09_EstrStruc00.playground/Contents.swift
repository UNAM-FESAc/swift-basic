/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

struct Alumno{
    var nombre:String;
    var edad:Int;
    var apellido:String;
}
