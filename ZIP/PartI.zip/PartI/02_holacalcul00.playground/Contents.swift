/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

var a = 2
var b = 3
var c = a + b
print(c)
