# Introducción a Swift

En este espacio (sesión) se encuentran y comparte 
documentación sobre el lenguaje de programación. 

Algunas actividades:
1. Compartir documentación sobre el lenguaje.
2. Participar en el kahoot.it
