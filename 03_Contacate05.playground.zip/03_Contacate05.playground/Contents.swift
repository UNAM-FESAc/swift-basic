/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos


print("Please Enter your favorite programming language", terminator: ".")
let name = readLine()
print("Your favorite programming language is \(name)")
