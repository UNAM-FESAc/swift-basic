/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos

var letra : Character = "A";
var cadena = "\(letra) todos: Hola Mundo"
print(cadena)
