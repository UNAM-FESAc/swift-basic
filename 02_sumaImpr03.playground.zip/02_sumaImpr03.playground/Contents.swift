/* ********************* TEXTO SIN ACENTOS *********************/
// Recuerda documentar tus codigos
var a:Int = 2
var b:Int = 3
print(a,"+" ,b, "=",a+b)
